#
# Copyright="� Microsoft Corporation. All rights reserved."
#

configuration PrepareWSFC
{
    param
    (
    )
 
    Node localhost
    {
        WindowsFeature FC
        {
            Name = "Failover-Clustering"
            Ensure = "Present"
        }

        WindowsFeature FailoverClusterTools 
        { 
            Ensure = "Present" 
            Name = "RSAT-Clustering-Mgmt"
            DependsOn = "[WindowsFeature]FC"
        } 

        WindowsFeature FCPS
        {
            Name = "RSAT-Clustering-PowerShell"
            Ensure = "Present"
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }

        WindowsFeature NetFx35
        {
            Name = "NET-Framework-Features"
            Ensure = "Present"
        }
    }  
}
